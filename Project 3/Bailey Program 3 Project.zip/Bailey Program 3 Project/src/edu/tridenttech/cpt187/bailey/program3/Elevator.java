//FILE:  Elevator.java
//PROG:  Taylor Bailey
//PURP:  Simulate the movement of an elevator


package edu.tridenttech.cpt187.bailey.program3;

public class Elevator 
{//Start Elevator Class
	//Class instance variables
	int numOnBoard;
	int maxCapacity;
	int currentFloor;
	int destFloor;
	int maxFloor;
	int minFloor;
	int numLeaving;
	
	public Elevator(int maxRiders, int curntFloor, int highestFloor, int lowestFloor)
	{
		numOnBoard = 0;
		maxCapacity = maxRiders;
		currentFloor = curntFloor;
		destFloor = currentFloor;
		maxFloor = highestFloor;
		minFloor = lowestFloor;
	}

	public int getNumOnBoard()
	{
		return numOnBoard;
	}
	
	public int getMaxCapacity()
	{
		return maxCapacity;
	}
	
	public int getCurrentFloor()
	{
		return currentFloor;
	}
	
	public int getDestFloor()
	{
		return destFloor;
	}
	
	public int getMaxFloor()
	{
		return maxFloor;
	}
	
	public int getMinFloor()
	{
		return minFloor;
	}
	
	public void loadElevator(int numBoarding)
	{//Start load
		if (numBoarding > 18)
		{
			numBoarding = 18 - numOnBoard;
			numOnBoard+=numBoarding;
			System.out.println("The number boarding the elevator is " + numBoarding + ".");
			System.out.println("The number of people currently on board is " + numOnBoard + ".");
		}
		else
		{
		numOnBoard+=numBoarding;
		System.out.println("The number boarding the elevator is " + numBoarding + ".");
		System.out.println("The number of people currently on board is " + numOnBoard + ".");
		}
	}//End load
	
	public void moveElevator(int requestedFloor)
	{//Start move
		while (requestedFloor > 99 || requestedFloor < 1)
		{
			System.out.println("Invalid floor number. We aren't going anywhere!");
			System.exit(0);
		}
		if (destFloor <= 99)
		{
			destFloor = requestedFloor;
			if (destFloor > currentFloor)
			{
				System.out.println("Going up from floor " + currentFloor + ".");
			}
			while (currentFloor < (destFloor - 1))
			{
				currentFloor++;
				System.out.println("Passing floor " + currentFloor + ".");
			}
			if (currentFloor == (destFloor - 1))
			{
				currentFloor++;
			}
			
			if (destFloor < currentFloor)
			{
				System.out.println("Going down from floor " + currentFloor + ".");
			}
			while (currentFloor > (destFloor + 1))
			{
				currentFloor--;
				System.out.println("Passing floor " + currentFloor + ".");
			}
			if (currentFloor == (destFloor + 1))
			{
				currentFloor--;
			}			
		}
		
		System.out.println("Made it to floor " + currentFloor + ".");
	}
	
	public void unloadElevator(int numLeaving)
	{//Start unload
		if (numLeaving > numOnBoard)
		{
			System.out.println("The number departing the elevator is " + numOnBoard + ".");
			numOnBoard = 0;
			System.out.println("The number of people currently on board is " + numOnBoard + ".");
		}
		else
		{
		numOnBoard-=numLeaving;
		System.out.println("The number departing the elevator is " + numLeaving + ".");
		System.out.println("The number of people currently on board is " + numOnBoard + ".");
		}
	}//End unload
	
}//End Elevator Class
