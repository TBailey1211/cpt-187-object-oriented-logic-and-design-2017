//FILE:  MainClass.java
//PROG:  Taylor Bailey
//PURP:  Simulate the movement of an elevator
//using the class Elevator

package edu.tridenttech.cpt187.bailey.program3;

public class MainClass 
{

	public static void main(String[] args) 
	{
		
		Elevator theElevator = new Elevator(18, 1, 99, 1);
		
		//Trip 1
		theElevator.loadElevator(5);
		
		theElevator.moveElevator(5);
		
		theElevator.unloadElevator(3);
		
		theElevator.loadElevator(5);
		
		System.out.println("\n");
		
		//Trip 2
		theElevator.loadElevator(2);
		
		theElevator.moveElevator(15);
		
		theElevator.unloadElevator(4);
		
		theElevator.loadElevator(11);
		
		System.out.println("\n");
		
		//Trip 3
        theElevator.loadElevator(30);
		
		theElevator.moveElevator(6);
		
		theElevator.unloadElevator(6);
		
		theElevator.loadElevator(2);
		
		System.out.println("\n");
		
		//Trip 4
		theElevator.loadElevator(3);
		
		theElevator.moveElevator(12);
		
		theElevator.unloadElevator(30);
		
		theElevator.loadElevator(5);
		
		System.out.println("\n");
		
		//Trip 5
		theElevator.loadElevator(5);
		
		theElevator.moveElevator(1);
		
		theElevator.unloadElevator(10);
		
		theElevator.loadElevator(0);
		
	}

}
