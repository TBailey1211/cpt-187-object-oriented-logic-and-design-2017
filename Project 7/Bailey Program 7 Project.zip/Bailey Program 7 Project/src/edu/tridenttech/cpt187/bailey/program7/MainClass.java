//FILE : MainClass.java
//PROG : Taylor Bailey
//PURP : Program to load and search data within arrays
//using the sequential and binary search method.

package edu.tridenttech.cpt187.bailey.program7;

import java.util.Scanner;

public class MainClass 
{

	public static void main(String[] args) 
	{
		InventoryData partPrice = new InventoryData();
		Scanner myScanner = new Scanner(System.in);
		Scanner input = new Scanner(System.in);
		String fileName = "inventoryPricing.dat";
		int index = 0;
		int location = 0;
		int target;
		int price;
		int mid;
		char runProgram = ' ';
		
		partPrice.loadArrays(fileName);
		
		//Ask if the user wants to input part numbers
		System.out.println("Welcome to Acme's Inventory Program! Would you like to start searching part numbers?");
		System.out.println("Please enter Y or N to start the program.");
		runProgram = myScanner.nextLine().charAt(0);
		runProgram = Character.toUpperCase(runProgram);
		
		// Check for a valid response of N or Y
		while (runProgram != 'N' && runProgram != 'Y')
		{
			System.out.printf("\n%s", "Invalid entry, please enter Y to input a part number or N to quit.");
			runProgram = myScanner.nextLine().charAt(0);
			runProgram = Character.toUpperCase(runProgram);	
		}
		
		while (runProgram == 'Y')
		{	
		
		System.out.println("Which part number would you like to search for?");
		
		target = myScanner.nextInt();
		
		location = partPrice.seqSearch(target);
		
		if (partPrice.getPrice(location) == -1)
		{
			System.out.println("Sequential did not find part number " + target + ".");
		}
		else
		{
		System.out.printf("Sequential found part number " + target + ", and its price is $" 
				+ partPrice.getPrice(location) + ".\n");
		}
		
		partPrice.binSearch(target);
		
		if (partPrice.getPrice(location) == -1)
		{
			System.out.println("Binary did not find part number " + target + ".");
		}
		else
		{
		System.out.printf("Binary found part number " + target + ", and its price is $"
				+ partPrice.getPrice(location) + ".\n");
		}
		
		//Continue while, asking if user wants to input another part
		System.out.println("\nWould you like to enter another part number?");
		System.out.println("Please enter Y to continue or N to quit.");
		runProgram = input.nextLine().charAt(0);
		runProgram = Character.toUpperCase(runProgram);
		
		// Check for a valid response of N or Y
		while (runProgram != 'N' && runProgram != 'Y')
		{
			System.out.printf("\n%s", "Invalid entry, please enter Y to input a part number or N to quit.");
			runProgram = input.nextLine().charAt(0);
			runProgram = Character.toUpperCase(runProgram);	
		}
		
		}//END runProgram
		
		if (runProgram == 'N')
		{
			System.out.println("Thank you for using Acme's Inventory Program. Have a nice day!");
		}
		
	}//END Main

}//END MainClass
