//FILE : InventoryData.java
//PROG : Taylor Bailey
//PURP : Class for the Inventory Data program.

package edu.tridenttech.cpt187.bailey.program7;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class InventoryData 
{

	private int[] partNum = new int[200];
	private double[] price = new double[200];
	private int partCount = 0;
	
	InventoryData(){} //Currently nothing done in constructor
	
	public void loadArrays(String filename)
	{
		partCount = 0;
		
		try
		{
			Scanner infile = new Scanner (new FileInputStream(filename));
			
			while (infile.hasNext())
			{
				//Read a complete record
				partNum[partCount] = infile.nextInt();
				price[partCount] = infile.nextDouble();
				
				//Increment the count of elements
				++partCount;
			}
			
			infile.close();
		}
		catch (IOException ex)
		{
			//If file has problems, set the count to -1
			partCount = -1;
			ex.printStackTrace();
		}
	}//END loadArrays
	
	public int seqSearch(int target)
	{
		int ind = 0;
		int location = -1;
		
		while (ind < partCount)
		{
			if (target == partNum[ind])
			{
				location = ind;
				ind = partCount;
			}
			else
			{
				++ind;
			}
		}
		return location;
	}//END seqSearch
	
	public int binSearch(int target)
	{
		int first = 0;
		int last = partCount - 1;
		boolean found = false;
		int mid = 0;
		
		while (first <= last && !found)
		{
			mid = (first + last)/2;
			if (partNum[mid] == target)
			{
				found = true;
			}
			else
			{
				if (partNum[mid] < target)
				{
					first = mid + 1;
				}
				else
				{
					last = mid - 1;
				}
			}
		}
		
		{
			if (found == true)
			{
				mid = -1;
			}
		}
		return mid;
	}//END binSearch
	
	public double getPrice(int location)
    {
        if (location >= 0 && location < partCount)
            return price[location];
        else
            return -1;
    }

}//END InventoryData
