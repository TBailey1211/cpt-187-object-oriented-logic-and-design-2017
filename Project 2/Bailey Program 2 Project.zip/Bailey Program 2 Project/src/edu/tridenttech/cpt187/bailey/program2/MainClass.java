//FILE:  MainClass.java
//PROG:  Taylor Bailey
//PURP:  Simulate a real bank savings account
//using the class SavingsAccount

package edu.tridenttech.cpt187.bailey.program2;

import java.util.Scanner;

public class MainClass 
{

	public static void main(String[] args) 
	{
		
        Scanner input = new Scanner(System.in);
		
		SavingsAccount myAccount = new SavingsAccount("26051", 4000.0, 0.004);
		String userName = "";
		double currentBalance;
		double currentRate;
		double interestEarned = 0;
		double endingBalance = 0;
		int count = 0;
		
		currentBalance = myAccount.getBalance();
		currentRate = myAccount.getRate();
		
		System.out.println("Welcome to the Programmer's National Bank. Please input your first name.");
		userName = input.nextLine();
		
		System.out.println("Okay, " + userName + ", here is the current state of your savings account:");
		System.out.println("Account #: " + myAccount.getAccountNumber());
	    System.out.printf("The current balance in this account is $%.2f\n", currentBalance, ".");
        System.out.println("The monthly interest rate for this account is 0.4%.");
		
		System.out.println("How much would you like to deposit into your account?");
		currentBalance = input.nextDouble();
		myAccount.addToBalance(currentBalance);
		
		System.out.println("How much would you like to withdraw?");
		currentBalance = input.nextDouble();
		myAccount.withdrawFromBalance(currentBalance);

		
		System.out.println("Okay, " + userName + ", here is the final state of your savings account:");
		System.out.println("Account #: " + myAccount.getAccountNumber());
	    System.out.printf("The current balance in this account is $%.2f\n",  myAccount.getBalance(),  ".");
        System.out.println("The monthly interest rate for this account is 0.4%.");
        
        System.out.println("Here is a 12-month summary for your account:");
        System.out.printf("Month%15s%15s%15s\n", "Starting", "Interest", "Ending");
		System.out.printf("#%18s%15s%17s\n", "Balance", "Earned", "Balance");
        
        while (count < 12)
        {
        	count += 1;
        	interestEarned = myAccount.getRate() * myAccount.getBalance();
        	endingBalance = myAccount.getBalance() + interestEarned;
        	System.out.printf(count + "%18.2f%15.2f%16.2f\n", myAccount.getBalance(), interestEarned, endingBalance);
        	applyInterest(myAccount);
        }
        
	}
	
	public static void applyInterest (SavingsAccount theAccount)
	{
		double currentBalance = theAccount.getBalance();
		double currentRate = theAccount.getRate();
		double interestEarned = currentBalance * currentRate;
		theAccount.addToBalance(interestEarned);
	}//END applyInterest
	
}//END MainClass
