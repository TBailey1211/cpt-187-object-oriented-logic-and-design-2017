//FILE:  MainClass.java
//PROG:  Taylor Bailey
//PURP:  Simulate a real bank savings account
//using the class SavingsAccount

package edu.tridenttech.cpt187.bailey.program1;

import java.util.Scanner;

public class MainClass 
{

	public static void main(String[] args) 
	{
		
        Scanner input = new Scanner(System.in);
		
		SavingsAccount myAccount = new SavingsAccount();
		String userName = "";
		double currentBalance;
		
		System.out.println("Welcome to the Programmer's National Bank. Please input your first name.");
		userName = input.nextLine();
		
		System.out.println("How much would you like to deposit to start your account?");
		currentBalance = input.nextDouble();
		myAccount.addToBalance(currentBalance);
		
		System.out.println("How much would you like to withdraw?");
		currentBalance = input.nextDouble();
		myAccount.withdrawFromBalance(currentBalance);
		
		currentBalance = myAccount.getBalance();
		
		System.out.println("Okay, " + userName + ", here is the current state of your savings account:");
		System.out.println("Account #: " + myAccount.getAccountNumber());
	    System.out.println("The current balance in this account is $" + currentBalance + ".");
        System.out.println("The interest rate for this account is " + myAccount.getRate() + "%.");
	
	}

}//END MainClass
