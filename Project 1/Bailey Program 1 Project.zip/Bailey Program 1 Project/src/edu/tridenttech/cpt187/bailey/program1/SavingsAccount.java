//FILE:  SavingsAccount.java
//PROG:  Taylor Bailey
//PURP:  Simulate a real bank savings account that
//allows deposits and withdrawals

package edu.tridenttech.cpt187.bailey.program1;

public class SavingsAccount 
{

	//The class's instance variables, previously referred to as "Data"
	private String accountNumber;
	private double balance;
	private double rate;
	
	public SavingsAccount()
	{
		balance = 0.0;
		accountNumber = "26051";
		rate = 0.5;
	}
	
	public String getAccountNumber()
	{
		return accountNumber;
	}
	
	public double getBalance()
	{
		return balance;
	}
	
	public double getRate()
	{
		return rate;
	}
	
	public void addToBalance(double amount)
	{
		balance+=amount;
	}

	public void withdrawFromBalance(double amount)
	{
		balance-=amount;
	}
}//END class SavingsAccount
