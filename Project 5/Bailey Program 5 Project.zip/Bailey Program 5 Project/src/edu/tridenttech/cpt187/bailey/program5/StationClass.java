//FILE : StationClass.java
//PROG : Taylor Bailey
//PURP : Class to represent the train station

package edu.tridenttech.cpt187.bailey.program5;

public class StationClass {
	
	private int passengersWaiting;
	
	public StationClass(int startWaiting)
	{
		passengersWaiting = startWaiting;
	}
	
	public int getPassengersWaiting()
	{
		return passengersWaiting;
	}
	
	public void reduceNumberWaiting(int peopleOnBoard)
	{
		passengersWaiting = passengersWaiting - peopleOnBoard;
	}

}
