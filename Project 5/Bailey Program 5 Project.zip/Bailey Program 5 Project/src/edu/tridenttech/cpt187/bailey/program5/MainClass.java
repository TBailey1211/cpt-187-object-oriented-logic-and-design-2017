//FILE : MainClass.java
//PROG : Taylor Bailey
//PURP : Simulate a high speed railway train with moves between a few stations
//Does not yet have the capability to load or unload passengers
package edu.tridenttech.cpt187.bailey.program5;

public class MainClass 
{
	public static void main(String[] args) 
	{
		final int STATIONCOUNT = 2;
		CommuterTrain trainOne = new CommuterTrain(STATIONCOUNT, 100, 1);
		
		StationClass stationOne = new StationClass(300);
		StationClass stationTwo = new StationClass(500);
		
		System.out.println("All aboard Train Number One!\n");
		
		while (stationOne.getPassengersWaiting() > 0 || stationTwo.getPassengersWaiting() > 0 )
		{
			if (stationOne.getPassengersWaiting() == 0)
			{
				trainOne.unloadAll();
				System.out.println("Returning to station #2.");
				trainOne.moveToStation(trainOne.getCurrentStation() + 1);
				
				trainOne.loadFromStation(stationTwo);
				trainOne.moveToStation(trainOne.getCurrentStation() - 1);
			}
			else if (stationTwo.getPassengersWaiting() == 0)
			{
				trainOne.unloadAll();
				System.out.println("Returning to station #1.");
				trainOne.moveToStation(trainOne.getCurrentStation() - 1);
			}
			else if (stationOne.getPassengersWaiting() == 0 && stationTwo.getPassengersWaiting() == 0)
			{
				System.out.println("No more passengers to load. Returning to station #1.");
			}
			else
			{
			stationOne.getPassengersWaiting();
			trainOne.loadFromStation(stationOne);
			trainOne.moveToStation(trainOne.getCurrentStation() + 1);
		
			trainOne.unloadAll();
			stationTwo.getPassengersWaiting();
			trainOne.loadFromStation(stationTwo);
			trainOne.moveToStation(trainOne.getCurrentStation() - 1);
			}
		}
		
		if (stationOne.getPassengersWaiting() == 0 && stationTwo.getPassengersWaiting() == 0)
		{
			trainOne.unloadAll();
		}
		
	}//END main
}//END MainClass
