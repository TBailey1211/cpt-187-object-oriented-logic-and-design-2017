//FILE : CommuterTrain.java
//PROG : Taylor Bailey
//PURP : Class to simulate a high speed railway train, with multiple stops
//and capability of loading and unloading passengers

package edu.tridenttech.cpt187.bailey.program5;

import java.util.Random;

public class CommuterTrain 
{
	private int peopleOnBoard;			//Number of pax on train
	private int maxCapacity;			//Max capacity of entire train
	private int currentStation;			//Number of the station the train is stopped at
	private int numStations;			//Number of stations serviced by this train
	private int destStation;			//Number of the next station to stop at
	private int peopleBoarding;
	private int peopleLeaving;
	private int passengersWaiting;
	private Random ranNumGenerator;
	
	public CommuterTrain(int stationCount, int maxPersons, int startStation)
	{
		numStations = stationCount;
		maxCapacity = maxPersons;
		currentStation = startStation;
		destStation = currentStation;
		peopleOnBoard = 0;			
		ranNumGenerator = new Random();
	}
	
	public int getPeopleOnBoard()
	{
		return peopleOnBoard;
	}
	
	public int getMaxCapacity()
	{
		return maxCapacity;
	}
	
	public int getCurrentStation()
	{
		return currentStation;
	}//END getCurntStation
	
	public int getDestStation()
	{
		return destStation;
	}
	
	public int genRandNumber(int maxNum)
	{
		//Generate a random integer <= maxNum
		return ranNumGenerator.nextInt(maxNum + 1);
	}//END genRandNumber
	
	public void moveToStation(int nextStation)
	{
		//if (nextStation > numStations)
		//{
			//System.out.println("\n");
			//System.out.println("We have reached the last station. Returning to station #1.");
			//System.out.println("We have reached station #1.");
		    //System.out.println("The number of passengers leaving the train is " + peopleOnBoard + ".");
		    //peopleOnBoard = 0;
		    //System.out.println("The number of passengers on board is " + peopleOnBoard + ".");
		    //System.exit(0);
		//}
		
		destStation = nextStation;
		
		//Move the train to the destination
		System.out.println("\n");
		System.out.printf("Leaving station #%d for station #%d with %d passengers.\n",
				currentStation, destStation, peopleOnBoard);
	
		currentStation = destStation;
	}//END moveToStation
	
	public void loadPax()
	{
		peopleOnBoard = genRandNumber(351);
		System.out.println("The number of passengers boarding the train is " + getPeopleOnBoard() + ".");
		
		if (peopleOnBoard > maxCapacity)
		{
			System.out.println("Too many people are trying to board! Allowing max limit to board. . .");
			peopleOnBoard = maxCapacity;
			System.out.println("The number of passengers boarding the train is " + getPeopleOnBoard() + ".");
		}
	}
	
	public void loadPeople()
	{
		peopleBoarding = genRandNumber(351);
		System.out.println("The number of passengers boarding the train is " + peopleBoarding + ".");
		if (peopleBoarding > maxCapacity)
		{
			System.out.println("Too many people are trying to board! Allowing max limit to board. . .");
			peopleBoarding = maxCapacity - peopleOnBoard;
			System.out.println("The number of passengers boarding the train is " + peopleBoarding + ".");
			peopleOnBoard+=peopleBoarding;
			System.out.println("The number of passengers on board is " + getPeopleOnBoard() + ".");
		}
		else
		{
			peopleOnBoard+=peopleBoarding;
			if (peopleOnBoard > maxCapacity)
			{
				System.out.println("Too many people are trying to board! Allowing max limit to board. . .");
				peopleOnBoard-=peopleBoarding;
				peopleBoarding = maxCapacity - peopleOnBoard;
				System.out.println("The number of passengers boarding the train is " + peopleBoarding + ".");
				peopleOnBoard+=peopleBoarding;
				System.out.println("The number of passengers on board is " + getPeopleOnBoard() + ".");
			}
			else
			{
			System.out.println("The number of passengers on board is " + getPeopleOnBoard() + ".");
			}
		}
	}
	
	public void unloadPeople()
	{
		getPeopleOnBoard();
		peopleLeaving = genRandNumber(peopleOnBoard);
		peopleOnBoard-=peopleLeaving;
		System.out.println("The number of passengers leaving the train is " + peopleLeaving + ".");
		System.out.println("The number of passengers on board is " + peopleOnBoard + ".");
	}
	
	public void loadFromStation(StationClass stationOne)
	{
		System.out.println("The number of passengers waiting to board is " + stationOne.getPassengersWaiting() + ".");
		peopleOnBoard = maxCapacity;
		stationOne.reduceNumberWaiting(peopleOnBoard);
		System.out.println("The number of passengers on board is " + getPeopleOnBoard() + ".");
		System.out.println("The number of passengers left to board is " + stationOne.getPassengersWaiting() + ".");
	}
	
	public void unloadAll()
	{
		peopleOnBoard = 0;
		System.out.println("Unloading passengers. . .");
		System.out.println("The number of passengers on board is " + getPeopleOnBoard() + ".");
	}

}//END class SubwayTrain
