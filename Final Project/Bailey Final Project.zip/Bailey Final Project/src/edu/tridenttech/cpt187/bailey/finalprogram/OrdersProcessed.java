package edu.tridenttech.cpt187.bailey.finalprogram;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class OrdersProcessed 
{

	public OrdersProcessed(String filename){} //Constructor
	
	public void saveOneRecord(int target, int partAmount, double partCost) 
	{//START saveOneRecord
		int partNum = target;
		int quantity = partAmount;
		double totalCost = partCost;

		try
		{
			PrintWriter myPW = new PrintWriter(new FileWriter("OrdersProcessed.dat", true));
			
			//Save one record
			myPW.printf("%s %s %.2f\n", partNum, quantity, totalCost);
			myPW.println("\r");
			
			myPW.close();
		}
		
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}//END saveOneRecord
}
