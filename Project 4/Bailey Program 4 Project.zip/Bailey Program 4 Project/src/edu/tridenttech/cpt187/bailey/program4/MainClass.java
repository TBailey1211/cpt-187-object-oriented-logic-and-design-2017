//FILE : MainClass.java
//PROG : Taylor Bailey
//PURP : Simulate a high speed railway train with moves between a few stations
//Does not yet have the capability to load or unload passengers
package edu.tridenttech.cpt187.bailey.program4;

public class MainClass 
{
	public static void main(String[] args) 
	{
		final int STATIONCOUNT = 30;
		CommuterTrain trainOne = new CommuterTrain(STATIONCOUNT, 200, 1);
		
		
		System.out.println("All aboard Train Number One!\n");
		trainOne.loadPax();
		for (int ct = 0; ct < STATIONCOUNT; ++ct)
		{
			trainOne.moveToStation(trainOne.getCurrentStation() + 1);
			trainOne.unloadPeople();
			trainOne.loadPeople();
		}
	}//END main
}//END MainClass
