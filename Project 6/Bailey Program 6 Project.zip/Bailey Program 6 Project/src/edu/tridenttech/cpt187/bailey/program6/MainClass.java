//FILE : MainClass.java
//PROG : Taylor Bailey
//PURP : Program to load and process data using an array
//     : Uses class IntegerArray.java and file program6.dat


package edu.tridenttech.cpt187.bailey.program6;

import java.util.Scanner;

public class MainClass 
{

	public static void main(String[] args) 
	{
		IntegerArray intEval = new IntegerArray();
		Scanner myScanner = new Scanner(System.in);
		String fileName = "program6.dat";
		int index = 0;
		int length;
		int arrayCount;
		
		intEval.loadArray(fileName);
		
		System.out.println("The numbers in this array are: ");
		
		intEval.displayArray();
		
		System.out.println("The average of numbers in this array is: ");
		
		System.out.println(intEval.calcAverage());
		
		System.out.println("The count of elements below the average is: ");
		
		System.out.println(intEval.countBelowAvg());
	}//END Main

}//END class MainClass
