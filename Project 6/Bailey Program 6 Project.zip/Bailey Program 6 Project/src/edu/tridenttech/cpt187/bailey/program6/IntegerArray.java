//FILE : IntegerArray.java
//PROG : Taylor Bailey
//PURP : Class for the Integer Array program.

package edu.tridenttech.cpt187.bailey.program6;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class IntegerArray 
{
	public int[] arrayNums = new int[100];
	private int arrayCount = 0;
	private int totalNums = 0;
	private int average;
	private int index;
	private int numBelowAvg;
	
	IntegerArray(){} //Constructor

	public void loadArray(String filename)
	{
		double integer;
		arrayCount = 0;
	
	try
	{
		Scanner infile = new Scanner (new FileInputStream(filename));
		
		while (infile.hasNext())
		{
			//Read the array
			arrayNums[arrayCount] = infile.nextInt();
			
			//Increment the count of elements
			++arrayCount;
		}
		
		infile.close();
	}
	catch (IOException ex)
	{
		//If file has problems, set the count to -1
		arrayCount = -1;
		ex.printStackTrace();
	}

}//END loadArray
	
	public void displayArray()
	{
		for (int index = 0; index < arrayCount; ++index)
			System.out.println(arrayNums[index]);
	}//END displayArray
	
	public int calcAverage()
	{
		for (int index = 0; index < arrayCount; ++index)
			totalNums+=arrayNums[index];
			totalNums = totalNums / arrayCount;
			return totalNums;
	}//END calcAverage
	
	public int countBelowAvg()
	{
		totalNums = calcAverage();
		for (int index = 0; index < arrayCount; ++index)
		if (arrayNums[index] < totalNums)
		{
		++numBelowAvg;
		}
		return numBelowAvg;
	}
	
}//END IntegerArray
